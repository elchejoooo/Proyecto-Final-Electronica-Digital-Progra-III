using System;
using System.IO.Ports;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DigitalProyectoFinal
{
    public partial class Form1 : Form
    {
        float precioBomba1, precioBomba2, precioBomba3, precioBomba4;
        private SerialPort spArduino;

        // Variable para saber si estamos en modo Tanque Lleno
        bool modoTanqueLleno = false;
        public Form1()
        {
            InitializeComponent();
            ConfigurarPuertoSerial();
            ActualizarLabelsPrecio();

        }
        // --- CONFIGURACI�N Y COMUNICACI�N ---

        private void ConfigurarPuertoSerial()
        {
            spArduino = new SerialPort();
            try
            {
                spArduino.PortName = "COM9"; // Ajustar seg�n tu administrador de dispositivos
                spArduino.BaudRate = 9600;

                // Suscribirse al evento de recepci�n de datos del Arduino
                spArduino.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);

                if (!spArduino.IsOpen) spArduino.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al conectar con Arduino: " + ex.Message);
            }
        }

        // Este m�todo se ejecuta cuando Arduino env�a el mensaje de "Tanque Lleno"
        private void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                string data = spArduino.ReadLine().Trim();

                // Si el Arduino detect� agua salada y mand� "LLENO"
                if (data.Contains("LLENO"))
                {
                    // Necesitamos Invoke porque el puerto serial corre en un hilo secundario
                    this.Invoke(new MethodInvoker(delegate {
                        lblEstadoGlobal.Text = "�DETECCI�N DE LLENADO! Sistema apagado.";
                        // El Arduino ya apaga los pines f�sicamente, aqu� solo avisamos al usuario
                        MessageBox.Show("El sensor ha detectado que el recipiente est� lleno.");
                    }));
                }
            }
            catch { /* Manejo de errores de lectura */ }
        }

        private void ActualizarLabelsPrecio()
        {
            lblPrecioActual.Text = $"Precio actual: {precioBomba1:C} | {precioBomba2:C} | {precioBomba3:C} | {precioBomba4:C}";
        }


        // --- M�TODOS DE CONTROL DE FLUJO (BOMBA �NICA) ---

        private async Task IniciarDespacho(int numeroBomba, int tiempoSegundos, Label lblEstadoIndividual)
        {
            if (spArduino.IsOpen)
            {
                // 1. Encender la BOMBA �NICA para generar presi�n
                spArduino.Write("b");
                lblEstadoGlobal.Text = "Generando presi�n en el sistema...";
                lblEstadoIndividual.Text = "Esperando presi�n...";

                // 2. Tiempo de presurizaci�n (5 segundos)
                await Task.Delay(5000);

                // 3. Encender la electrov�lvula correspondiente
                spArduino.Write(numeroBomba.ToString());
                lblEstadoGlobal.Text = $"Despachando en Estaci�n {numeroBomba}...";
                lblEstadoIndividual.Text = "Estado: ABIERTO";

                // 4. Tiempo de llenado (Simulando 1 litro en 3 min -> 180s)
                await Task.Delay(tiempoSegundos * 1000);

                // 5. Finalizar proceso: Apagar v�lvula y luego bomba
                FinalizarCerrado(numeroBomba, lblEstadoIndividual);
            }
            else
            {
                MessageBox.Show("El puerto serial no est� abierto.");
            }
        }

        private void FinalizarCerrado(int numeroBomba, Label lblEstadoIndividual)
        {
            string[] comandosApagado = { "q", "w", "e", "r" };

            if (spArduino.IsOpen)
            {
                spArduino.Write(comandosApagado[numeroBomba - 1]); // Enviar comando de cierre de v�lvula
                System.Threading.Thread.Sleep(500); // Pausa m�nima de seguridad
                spArduino.Write("x"); // Apagar la Bomba �nica
            }

            lblEstadoGlobal.Text = "Sistema listo / Esperando orden";
            lblEstadoIndividual.Text = "Estado: CERRADO";
        }

        //ESPACIO DE FUNCIONES DE COMPONENTES VISUALES
        private void btnAjustarPrecio1_Click(object sender, EventArgs e)
        {
            if (float.TryParse(txtPrecioBomba1.Text, out precioBomba1))
            {
                MessageBox.Show("Precio de la bomba 1 ajustado.");
                ActualizarLabelsPrecio();
            }
        }

        private void btnAjustarPrecio2_Click(object sender, EventArgs e)
        {
            if (float.TryParse(txtPrecioBomba2.Text, out precioBomba2))
            {
                MessageBox.Show("Precio de la bomba 2 ajustado.");
                ActualizarLabelsPrecio();
            }
        }

        private void btnAjustarPrecio3_Click(object sender, EventArgs e)
        {
            if (float.TryParse(txtPrecioBomba3.Text, out precioBomba3))
            {
                MessageBox.Show("Precio de la bomba 3 ajustado.");
                ActualizarLabelsPrecio();
            }
        }

        private void btnAjustarPrecio4_Click(object sender, EventArgs e)
        {
            if (float.TryParse(txtPrecioBomba4.Text, out precioBomba4))
            {
                MessageBox.Show("Precio de la bomba 4 ajustado.");
                ActualizarLabelsPrecio();
            }
        }

        // --- L�GICA DE ENCENDIDO (PREPAGO Y TANQUE LLENO) ---
        // Funci�n auxiliar para procesar el encendido seg�n el modo
        private async void ProcesarEncendidoBomba(int numeroBomba, float precioBomba, Label lblEstado)
        {
            // CASO A: Modo Tanque Lleno activo
            if (modoTanqueLleno)
            {
                lblEstadoGlobal.Text = $"Modo Tanque Lleno en Estaci�n {numeroBomba}...";
                // Enviamos un tiempo muy largo (1 hora), el sensor de cobre cortar� antes
                await IniciarDespacho(numeroBomba, 3600, lblEstado);
                modoTanqueLleno = false; // Resetear modo para la siguiente venta
            }
            // CASO B: Modo Prepago (usando el texto de txtPagoPrepago)
            else
            {
                float monto;
                if (float.TryParse(txtPagoPrepago.Text, out monto) && precioBomba > 0)
                {
                    float litros = monto / precioBomba;
                    int tiempoSegundos = (int)(litros * 180); // 1 litro = 180 seg

                    lblEstadoGlobal.Text = $"Pago: {monto:C}. Litros: {litros:F2}L";
                    await IniciarDespacho(numeroBomba, tiempoSegundos, lblEstado);
                    txtPagoPrepago.Clear();
                }
                else
                {
                    MessageBox.Show("Ingrese un monto de prepago v�lido o verifique el precio de la bomba.");
                }
            }
        }


        private void btnEncenderBomba1_Click(object sender, EventArgs e)
        {
            ProcesarEncendidoBomba(1, precioBomba1, lblEstadoBomba1);
        }

        private void btnEncenderBomba2_Click(object sender, EventArgs e)
        {
            ProcesarEncendidoBomba(2, precioBomba2, lblEstadoBomba2);
        }

        private void btnEncenderBomba3_Click(object sender, EventArgs e)
        {
            ProcesarEncendidoBomba(3, precioBomba3, lblEstadoBomba3);
        }

        private void btnEncenderBomba4_Click(object sender, EventArgs e)
        {
            ProcesarEncendidoBomba(4, precioBomba4, lblEstadoBomba4);
        }

        // --- BOTONES DE APAGADO MANUAL ---

        private void btnApagarBomba1_Click(object sender, EventArgs e)
        {
            FinalizarCerrado(1, lblEstadoBomba1);
        }

        private void btnApagarBomba2_Click(object sender, EventArgs e)
        {
            FinalizarCerrado(2, lblEstadoBomba2);
        }

        private void btnApagarBomba3_Click(object sender, EventArgs e)
        {
            FinalizarCerrado(3, lblEstadoBomba3);
        }

        private void btnApagarBomba4_Click(object sender, EventArgs e)
        {
            FinalizarCerrado(4, lblEstadoBomba4);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (spArduino.IsOpen) spArduino.Close();
        }

        // --- EVENTOS DE CIERRE Y SELECCI�N DE PAGO ---
        private void btnPagoPrepago_Click(object sender, EventArgs e)
        {
            modoTanqueLleno = false;
            if (string.IsNullOrEmpty(txtPagoPrepago.Text))
                MessageBox.Show("Ingrese el monto para prepago.");
            else
                lblEstadoGlobal.Text = "Modo Prepago: " + txtPagoPrepago.Text + ". Seleccione bomba.";
        }

        private void btnPagoTanqueTotal_Click(object sender, EventArgs e)
        {
            modoTanqueLleno = true;
            lblEstadoGlobal.Text = "Modo: Tanque Lleno Activo. Seleccione Bomba.";
        }
    }
}
