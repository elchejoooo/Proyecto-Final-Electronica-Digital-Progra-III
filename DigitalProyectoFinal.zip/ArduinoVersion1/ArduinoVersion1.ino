// Pin de la bomba única
const int pinBomba = 2; 
// Pines de las 4 electroválvulas
int valvulas[] = {3, 4, 5, 6}; 

void setup() {
  Serial.begin(9600);
  pinMode(pinBomba, OUTPUT);
  digitalWrite(pinBomba, LOW);
  
  for(int i=0; i<4; i++) {
    pinMode(valvulas[i], OUTPUT);
    digitalWrite(valvulas[i], LOW);
  }
}

void loop() {
  if (Serial.available() > 0) {
    char cmd = Serial.read();
    switch(cmd) {
      case 'b': digitalWrite(pinBomba, HIGH); break;
      case 'x': digitalWrite(pinBomba, LOW); break;
      
      case '1': digitalWrite(valvulas[0], HIGH); break;
      case 'q': digitalWrite(valvulas[0], LOW); break;
      
      case '2': digitalWrite(valvulas[1], HIGH); break;
      case 'w': digitalWrite(valvulas[1], LOW); break;
      
      case '3': digitalWrite(valvulas[2], HIGH); break;
      case 'e': digitalWrite(valvulas[2], LOW); break;
      
      case '4': digitalWrite(valvulas[3], HIGH); break;
      case 'r': digitalWrite(valvulas[3], LOW); break;
    }
  }
}