using System;
using System.IO; // Necesario para el manejo de archivos TXT
using System.IO.Ports;
using System.Linq; // Nos ayuda con la l�gica anal�tica de las bombas de manera eficiente
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DigitalProyectoFinal
{
    public partial class Form1 : Form
    {
        float precioBomba1, precioBomba2, precioBomba3, precioBomba4;
        private SerialPort spArduino;

        // Variable para saber si estamos en modo Tanque Lleno
        bool modoTanqueLleno = false;

        // Nombre del archivo para guardar los registros
        private const string ArchivoBitacora = "bitacora_ventas.txt";

        // Variables auxiliares para el registro en tiempo real de la venta actual
        private string modoActual = "Ninguno";
        private float montoActual = 0f;
        private float litrosActuales = 0f;
        public Form1()
        {
            InitializeComponent();
            ConfigurarPuertoSerial();
            ActualizarLabelsPrecio();

        }
        // --- CONFIGURACI�N Y COMUNICACI�N ---

        private void ConfigurarPuertoSerial()
        {
            spArduino = new SerialPort();
            try
            {
                spArduino.PortName = "COM9"; // Ajustar seg�n tu administrador de dispositivos
                spArduino.BaudRate = 9600;

                // Suscribirse al evento de recepci�n de datos del Arduino
                spArduino.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);

                if (!spArduino.IsOpen) spArduino.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al conectar con Arduino: " + ex.Message);
            }
        }
        private int DetectarBombaActiva()
        {
            if (lblEstadoBomba1.Text.Contains("ABIERTO")) return 1;
            if (lblEstadoBomba2.Text.Contains("ABIERTO")) return 2;
            if (lblEstadoBomba3.Text.Contains("ABIERTO")) return 3;
            if (lblEstadoBomba4.Text.Contains("ABIERTO")) return 4;
            return 1; // Por defecto
        }

        // Este m�todo se ejecuta cuando Arduino env�a el mensaje de "Tanque Lleno"
        private void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                string data = spArduino.ReadLine().Trim();

                // Si el Arduino detect� agua salada y mand� "LLENO"
                if (data.Contains("LLENO"))
                {
                    // Necesitamos Invoke porque el puerto serial corre en un hilo secundario
                    this.Invoke(new MethodInvoker(delegate
                    {
                        lblEstadoGlobal.Text = "�DETECCI�N DE LLENADO! Sistema apagado.";
                        // El Arduino ya apaga los pines f�sicamente, aqu� solo avisamos al usuario
                        MessageBox.Show("El sensor ha detectado que el recipiente est� lleno.");
                    }));
                }
            }
            catch { /* Manejo de errores de lectura */ }
        }

        private void ActualizarLabelsPrecio()
        {
            lblPrecioActual.Text = $"Precio actual: {precioBomba1:C} | {precioBomba2:C} | {precioBomba3:C} | {precioBomba4:C}";
        }


        // --- M�TODOS DE CONTROL DE FLUJO (BOMBA �NICA) ---

        private async Task IniciarDespacho(int numeroBomba, int tiempoSegundos, Label lblEstadoIndividual)
        {
            if (spArduino.IsOpen)
            {
                spArduino.Write("b");
                lblEstadoGlobal.Text = "Generando presi�n en el sistema...";
                lblEstadoIndividual.Text = "Esperando presi�n...";

                await Task.Delay(5000);

                spArduino.Write(numeroBomba.ToString());
                lblEstadoGlobal.Text = $"Despachando en Estaci�n {numeroBomba}...";
                lblEstadoIndividual.Text = "Estado: ABIERTO";

                await Task.Delay(tiempoSegundos * 1000);

                // Si llega al final del tiempo del delay de forma normal sin cortarse por sensor, es Prepago completado
                if (modoActual == "Prepago")
                {
                    RegistrarVentaEnBitacora(numeroBomba, "Prepago", montoActual, litrosActuales);
                }

                FinalizarCerrado(numeroBomba, lblEstadoIndividual);
            }
            else
            {
                MessageBox.Show("El puerto serial no est� abierto.");
            }
        }

        private void FinalizarCerrado(int numeroBomba, Label lblEstadoIndividual)
        {
            string[] comandosApagado = { "q", "w", "e", "r" };

            if (spArduino.IsOpen)
            {
                spArduino.Write(comandosApagado[numeroBomba - 1]);
                System.Threading.Thread.Sleep(500);
                spArduino.Write("x");
            }

            lblEstadoGlobal.Text = "Sistema listo / Esperando orden";
            lblEstadoIndividual.Text = "Estado: CERRADO";
        }
        private void RegistrarVentaEnBitacora(int numeroBomba, string modo, float monto, float litros)
        {
            try
            {
                // Formato csv interno: Fecha|Bomba|Modo|Monto|Litros
                string linea = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss}|{numeroBomba}|{modo}|{monto:F2}|{litros:F2}";

                using (StreamWriter sw = File.AppendText(ArchivoBitacora))
                {
                    sw.WriteLine(linea);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar el log en TXT: " + ex.Message);
            }
        }

        //ESPACIO DE FUNCIONES DE COMPONENTES VISUALES
        private void btnAjustarPrecio1_Click(object sender, EventArgs e)
        {
            if (float.TryParse(txtPrecioBomba1.Text, out precioBomba1))
            {
                MessageBox.Show("Precio de la bomba 1 ajustado.");
                ActualizarLabelsPrecio();
            }
        }

        private void btnAjustarPrecio2_Click(object sender, EventArgs e)
        {
            if (float.TryParse(txtPrecioBomba2.Text, out precioBomba2))
            {
                MessageBox.Show("Precio de la bomba 2 ajustado.");
                ActualizarLabelsPrecio();
            }
        }

        private void btnAjustarPrecio3_Click(object sender, EventArgs e)
        {
            if (float.TryParse(txtPrecioBomba3.Text, out precioBomba3))
            {
                MessageBox.Show("Precio de la bomba 3 ajustado.");
                ActualizarLabelsPrecio();
            }
        }

        private void btnAjustarPrecio4_Click(object sender, EventArgs e)
        {
            if (float.TryParse(txtPrecioBomba4.Text, out precioBomba4))
            {
                MessageBox.Show("Precio de la bomba 4 ajustado.");
                ActualizarLabelsPrecio();
            }
        }

        // --- L�GICA DE ENCENDIDO (PREPAGO Y TANQUE LLENO) ---
        // Funci�n auxiliar para procesar el encendido seg�n el modo
        private async void ProcesarEncendidoBomba(int numeroBomba, float precioBomba, Label lblEstado)
        {
            // CASO A: Modo Tanque Lleno activo
            if (modoTanqueLleno)
            {
                lblEstadoGlobal.Text = $"Modo Tanque Lleno en Estaci�n {numeroBomba}...";
                // Enviamos un tiempo muy largo (1 hora), el sensor de cobre cortar� antes
                await IniciarDespacho(numeroBomba, 3600, lblEstado);
                modoTanqueLleno = false; // Resetear modo para la siguiente venta
            }
            // CASO B: Modo Prepago (usando el texto de txtPagoPrepago)
            else
            {
                float monto;
                if (float.TryParse(txtPagoPrepago.Text, out monto) && precioBomba > 0)
                {
                    float litros = monto / precioBomba;
                    int tiempoSegundos = (int)(litros * 180); // 1 litro = 180 seg

                    lblEstadoGlobal.Text = $"Pago: {monto:C}. Litros: {litros:F2}L";
                    await IniciarDespacho(numeroBomba, tiempoSegundos, lblEstado);
                    txtPagoPrepago.Clear();
                }
                else
                {
                    MessageBox.Show("Ingrese un monto de prepago v�lido o verifique el precio de la bomba.");
                }
            }
        }


        private void btnEncenderBomba1_Click(object sender, EventArgs e)
        {
            ProcesarEncendidoBomba(1, precioBomba1, lblEstadoBomba1);
        }

        private void btnEncenderBomba2_Click(object sender, EventArgs e)
        {
            ProcesarEncendidoBomba(2, precioBomba2, lblEstadoBomba2);
        }

        private void btnEncenderBomba3_Click(object sender, EventArgs e)
        {
            ProcesarEncendidoBomba(3, precioBomba3, lblEstadoBomba3);
        }

        private void btnEncenderBomba4_Click(object sender, EventArgs e)
        {
            ProcesarEncendidoBomba(4, precioBomba4, lblEstadoBomba4);
        }

        // --- BOTONES DE APAGADO MANUAL ---

        private void btnApagarBomba1_Click(object sender, EventArgs e)
        {
            FinalizarCerrado(1, lblEstadoBomba1);
        }

        private void btnApagarBomba2_Click(object sender, EventArgs e)
        {
            FinalizarCerrado(2, lblEstadoBomba2);
        }

        private void btnApagarBomba3_Click(object sender, EventArgs e)
        {
            FinalizarCerrado(3, lblEstadoBomba3);
        }

        private void btnApagarBomba4_Click(object sender, EventArgs e)
        {
            FinalizarCerrado(4, lblEstadoBomba4);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (spArduino != null && spArduino.IsOpen) spArduino.Close();
        }

        // --- EVENTOS DE CIERRE Y SELECCI�N DE PAGO ---
        private void btnPagoPrepago_Click(object sender, EventArgs e)
        {
            modoTanqueLleno = false;
            if (string.IsNullOrEmpty(txtPagoPrepago.Text))
                MessageBox.Show("Ingrese el monto para prepago.");
            else
                lblEstadoGlobal.Text = "Modo Prepago: " + txtPagoPrepago.Text + ". Seleccione bomba.";
        }

        private void btnPagoTanqueTotal_Click(object sender, EventArgs e)
        {
            modoTanqueLleno = true;
            lblEstadoGlobal.Text = "Modo: Tanque Lleno Activo. Seleccione Bomba.";
        }
        //APARTADO DE LOS INFORMES
        private void btnCierreDiario_Click(object sender, EventArgs e)
        {
            if (!File.Exists(ArchivoBitacora))
            {
                MessageBox.Show("No hay registros de transacciones el d�a de hoy.");
                return;
            }

            float totalDinero = 0;
            float totalLitros = 0;
            int transacciones = 0;

            string[] lineas = File.ReadAllLines(ArchivoBitacora);
            foreach (string linea in lineas)
            {
                string[] datos = linea.Split('|');
                if (datos.Length >= 5)
                {
                    totalDinero += float.Parse(datos[3]);
                    totalLitros += float.Parse(datos[4]);
                    transacciones++;
                }
            }

            string reporte = $"*** CIERRE DIARIO DE OPERACIONES ***\n\n" +
                             $"Transacciones Totales: {transacciones}\n" +
                             $"Total Recaudado: {totalDinero:C}\n" +
                             $"Total de Litros Despachados: {totalLitros:F2} L";

            MessageBox.Show(reporte, "Cierre de Caja");
        }

        private void btnInformesPrepago_Click(object sender, EventArgs e)
        {
            if (!File.Exists(ArchivoBitacora)) return;

            float dineroPrepago = 0;
            int contador = 0;

            string[] lineas = File.ReadAllLines(ArchivoBitacora);
            foreach (string linea in lineas)
            {
                string[] datos = linea.Split('|');
                if (datos.Length >= 5 && datos[2].Contains("Prepago"))
                {
                    dineroPrepago += float.Parse(datos[3]);
                    contador++;
                }
            }

            MessageBox.Show($"*** REPORTE MODO PREPAGO ***\n\nDespachos realizados: {contador}\nTotal Ingresos: {dineroPrepago:C}", "Reporte Prepago");
        }

        private void btnInformesTanqueLleno_Click(object sender, EventArgs e)
        {
            if (!File.Exists(ArchivoBitacora)) return;

            int contador = 0;

            string[] lineas = File.ReadAllLines(ArchivoBitacora);
            foreach (string linea in lineas)
            {
                string[] datos = linea.Split('|');
                if (datos.Length >= 5 && datos[2].Contains("Tanque Lleno"))
                {
                    contador++;
                }
            }

            MessageBox.Show($"*** REPORTE TANQUE LLENO ***\n\nCantidad de veces que los sensores de cobre detuvieron el llenado completo: {contador} veces.", "Reporte Sensores de Nivel");
        }

        private void btnInformeUsoBombas_Click(object sender, EventArgs e)
        {
            if (!File.Exists(ArchivoBitacora))
            {
                MessageBox.Show("No hay historial suficiente para calcular estad�sticas.");
                return;
            }

            // Inicializamos un arreglo contador para las 4 bombas (�ndices 0 a 3 mapean a Bombas 1 a 4)
            int[] conteoBombas = new int[4];

            string[] lineas = File.ReadAllLines(ArchivoBitacora);
            foreach (string linea in lineas)
            {
                string[] datos = linea.Split('|');
                if (datos.Length >= 5)
                {
                    int idBomba = int.Parse(datos[1]);
                    if (idBomba >= 1 && idBomba <= 4)
                    {
                        conteoBombas[idBomba - 1]++;
                    }
                }
            }

            // Encontrar la m�s usada y menos usada usando l�gica algor�tmica elemental
            int maxUsos = conteoBombas.Max();
            int minUsos = conteoBombas.Min();

            int bombaMasUsada = Array.IndexOf(conteoBombas, maxUsos) + 1;
            int bombaMenosUsada = Array.IndexOf(conteoBombas, minUsos) + 1;

            string estadisticas = $"*** ESTAD�STICAS DE USO DE BOMBAS ***\n\n" +
                                 $"Bomba 1: {conteoBombas[0]} veces\n" +
                                 $"Bomba 2: {conteoBombas[1]} veces\n" +
                                 $"Bomba 3: {conteoBombas[2]} veces\n" +
                                 $"Bomba 4: {conteoBombas[3]} veces\n\n" +
                                 $"Bomba M�S utilizada: Bomba {bombaMasUsada} ({maxUsos} usos)\n" +
                                 $"Bomba MENOS utilizada: Bomba {bombaMenosUsada} ({minUsos} usos)";

            MessageBox.Show(estadisticas, "An�lisis de Infraestructura");
        }
    }
}
